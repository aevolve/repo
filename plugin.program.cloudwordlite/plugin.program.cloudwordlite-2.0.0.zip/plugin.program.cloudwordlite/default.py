#!/usr/bin/env python
#
#    #######################################
#
#    Author Josh.5  https://github.com/josh5
#
#    #######################################

import xbmcaddon

def main():
    xbmcaddon.Addon(id = 'plugin.program.cloudwordlite').openSettings()

if __name__ == '__main__': 
    main()
