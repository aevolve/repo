#!/usr/bin/env python
#
######################################################################
##                                                                  ##
#                                                                    #
#   ARNU Cloudword installer v2.                                     #
#                                                                    #
#   Credits:                                                         #
#     - ARNU for the orignal script                                  #
#                                                                    #
#   Written by:	Josh.5  https://github.com/josh5                     #
#   Date:	2015/07/31                                           #
#   Version:	2                                                    #
#                                                                    #
##                                                                  ##
######################################################################
#
if 64 - 64: i11iIiiIii
import urllib , urllib2 , sys , re , xbmcplugin , xbmcgui , xbmcaddon , xbmc , os
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
import socket , fcntl , struct
import shutil , subprocess , time , zipfile
if 73 - 73: II111iiii
IiII1IiiIiI1 = xbmcaddon . Addon ( id = 'plugin.program.cloudwordlite' )
iIiiiI1IiI1I1 = IiII1IiiIiI1 . getAddonInfo ( 'id' )
o0OoOoOO00 = IiII1IiiIiI1 . getAddonInfo ( 'name' )
I11i = IiII1IiiIiI1 . getAddonInfo ( 'icon' )
O0O = IiII1IiiIiI1 . getAddonInfo ( 'version' )
Oo = xbmc . translatePath ( "special://profile/addon_data/plugin.program.cloudwordlite/" )
I1ii11iIi11i = IiII1IiiIiI1 . getAddonInfo ( "path" )
if 48 - 48: oO0o / OOooOOo / I11iIi1I / IiiIII111iI
def IiII ( ) :
 iI1Ii11111iIi = xbmcgui . Dialog ( )
 i1i1II = xbmcgui . DialogProgress ( )
 O0oo0OO0 = I1i1iiI1 ( )
 iiIIIII1i1iI = 'http://www.armadatvboxota.com/api/cwl.php?k=' + O0oo0OO0 + '&m1=' + o0oO0 ( 'en0' ) + '&m2=' + o0oO0 ( 'eth0' ) + '&m3=' + o0oO0 ( 'wlan0' )
 oo00 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
 o00 = os . path . join ( oo00 , O0oo0OO0 + '.zip' )
 Oo0oO0ooo = xbmc . translatePath ( os . path . join ( 'special://home' , '' ) )
 o0oOoO00o = xbmc . translatePath ( os . path . expanduser ( '~/' ) )
 if 43 - 43: O0OOo . II1Iiii1111i
 i1i1II . create ( o0OoOoOO00 , "Downloading & Copying File" , '' , 'In Progress...' )
 i1IIi11111i ( iiIIIII1i1iI , o00 , i1i1II )
 i1i1II . close ( )
 if 74 - 74: Oo0o00o0Oo0 * ii11
 i1i1II . create ( o0OoOoOO00 , "Cloud Install" , '' , 'In Progress...' )
 i1i1II . update ( 0 , "" , " " , "Extracting Files..." )
 I1I1i1 ( o00 , Oo0oO0ooo , i1i1II )
 i1i1II . close ( )
 if IiI1i ( ) :
  if os . path . isdir ( os . path . join ( Oo0oO0ooo , 'ROOT' ) ) :
   i1i1II . create ( o0OoOoOO00 , "Cloud Install" , '' , 'In Progress...' )
   if 61 - 61: oo0O000OoO + IiiIIiiI11 / oooOOOOO * i1iiIII111ii
   i1i1II . update ( 0 , "" , " " , "Installing files to /root/..." )
   i1iIIi1 ( os . path . join ( Oo0oO0ooo , 'ROOT' ) , o0oOoO00o , i1i1II )
   shutil . rmtree ( os . path . join ( Oo0oO0ooo , 'ROOT' ) )
   i1i1II . close ( )
  ii11iIi1I = iI1Ii11111iIi . yesno ( o0OoOoOO00 , "Cloud Setup Complete! [CR]A restart may be required for some changes to take effect.[CR]Would you like to restart now?" , nolabel = 'Yes' , yeslabel = 'No' )
  if not ii11iIi1I :
   subprocess . Popen ( 'pkill -9 kodi && reboot' , shell = True , close_fds = True )
  else :
   xbmc . executebuiltin ( 'UpdateLocalAddons' )
   xbmc . executebuiltin ( 'UpdateAddonRepos' )
   iI1Ii11111iIi . ok ( "CLOUDWORD" , "Cloud Setup Complete" , "" , "[COLOR red]All Done Press Ok[/COLOR]" )
 else :
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  iI1Ii11111iIi . ok ( "CLOUDWORD" , "Cloud Setup Complete" , "" , "[COLOR red]All Done Press Ok[/COLOR]" )
  if os . path . isdir ( os . path . join ( Oo0oO0ooo , 'ROOT' ) ) :
   shutil . rmtree ( os . path . join ( Oo0oO0ooo , 'ROOT' ) )
   if 6 - 6: I1I11I1I1I * OooO0OO
def I1i1iiI1 ( ) :
 iiiIi = ''
 IiIIIiI1I1 = xbmc . Keyboard ( iiiIi , 'Enter CLOUDWORD' )
 IiIIIiI1I1 . doModal ( )
 if IiIIIiI1I1 . isConfirmed ( ) :
  iiiIi = IiIIIiI1I1 . getText ( ) . replace ( ' ' , '%20' )
  if iiiIi == None :
   return False
 return iiiIi
 if 86 - 86: i11iIiiIii + IiiIIiiI11 + OooO0OO * oo0O000OoO + O0OOo
def i1IIi11111i ( url , dest , dp = None ) :
 try :
  if 61 - 61: I11iIi1I / i11iIiiIii
  import sys
  if sys . version_info < ( 2 , 7 , 9 ) : raise Exception ( )
  import ssl ; IiIiIi = ssl . create_default_context ( )
  IiIiIi . check_hostname = False
  IiIiIi . verify_mode = ssl . CERT_NONE
  II = urllib2 . urlopen ( url , context = IiIiIi )
 except Exception , iI :
  print "Exception: " + str ( iI )
  II = urllib2 . urlopen ( url )
 if not dp :
  if 22 - 22: OOooOOo % IiiIIiiI11
  oo = open ( dest , 'wb' )
  OO0O00 = 0
  ii1 = 8192
  while True :
   buffer = II . read ( ii1 )
   if not buffer :
    break
   OO0O00 += len ( buffer )
   oo . write ( buffer )
  oo . close ( )
 else :
  if 57 - 57: IiiIIiiI11 % OoooooooOO
  dp . update ( 0 )
  oo = open ( dest , 'wb' )
  O00 = II . info ( )
  i11I1 = int ( O00 . getheaders ( "Content-Length" ) [ 0 ] )
  Ii11Ii11I = time . time ( )
  OO0O00 = 0
  ii1 = 8192
  while True :
   buffer = II . read ( ii1 )
   if not buffer :
    break
   OO0O00 += len ( buffer )
   oo . write ( buffer )
   iI11i1I1 = ( 100 * OO0O00 / i11I1 )
   o0o0OOO0o0 = OO0O00 / ( 1024 * 1024 )
   ooOOOo0oo0O0 = float ( i11I1 ) / ( 1024 * 1024 )
   o0 = OO0O00 / ( time . time ( ) - Ii11Ii11I )
   if o0 > 0 :
    I11II1i = ( i11I1 - OO0O00 ) / o0
   else :
    I11II1i = 0
   IIIII = o0 / 1024
   ooooooO0oo = '%.02f MB of %.02f MB' % ( o0o0OOO0o0 , ooOOOo0oo0O0 )
   iI = 'Speed: %.02f Kb/s ' % IIIII
   iI += 'ETA: %02d:%02d' % divmod ( I11II1i , 60 )
   dp . update ( iI11i1I1 , '' , ooooooO0oo , iI )
   if dp . iscanceled ( ) :
    raise Exception ( 'Canceled' )
  oo . close ( )
  if 49 - 49: O0OOo * iIii1I11I1II1 / i1IIi / i11iIiiIii / O0OOo
def i1iIIi1 ( source , destination , dp = None ) :
 try :
  xbmc . log ( o0OoOoOO00 + ': Folder Copy Started' , level = xbmc . LOGDEBUG )
  I1i1I1II = [ ]
  if os . path . isdir ( source ) :
   for oo00 , i1 , IiIiiI in os . walk ( source ) :
    I1i1I1II . extend ( IiIiiI )
  I1I = len ( I1i1I1II )
  if I1I > 0 :
   if not os . path . exists ( destination ) :
    os . makedirs ( destination )
   oOO00oOO = 0
   Ii11Ii11I = time . time ( )
   for oo00 , i1 , IiIiiI in os . walk ( source ) :
    for OoOo in i1 :
     iIo00O = oo00 . replace ( source , destination )
     if not os . path . exists ( os . path . join ( iIo00O , OoOo ) ) :
      os . makedirs ( os . path . join ( iIo00O , OoOo ) )
    for OOO0OOO00oo in IiIiiI :
     Iii111II = os . path . join ( oo00 , OOO0OOO00oo )
     iiii11I = os . path . join ( oo00 . replace ( source , destination ) , OOO0OOO00oo )
     try :
      shutil . copy ( Iii111II , iiii11I )
     except Exception , iI :
      xbmc . log ( o0OoOoOO00 + ': Failed to move file' , level = xbmc . LOGDEBUG )
      xbmc . log ( str ( iI ) , level = xbmc . LOGERROR )
      pass
     oOO00oOO += 1
     Ooo0OO0oOO = int ( round ( ( oOO00oOO / float ( I1I ) ) * 100 ) )
     o0 = oOO00oOO / ( time . time ( ) - Ii11Ii11I )
     if o0 > 0 :
      I11II1i = ( float ( I1I ) - oOO00oOO ) / o0
     else :
      I11II1i = 0
     IIIII = o0 / 1024
     if dp :
      if 50 - 50: oO0o
      dp . update ( Ooo0OO0oOO )
      if dp . iscanceled ( ) :
       return False
  return destination
 except Exception , iI :
  if 34 - 34: oO0o * II111iiii % oooOOOOO * IiiIII111iI - oO0o
  xbmc . log ( o0OoOoOO00 + ': Exception occurred' , level = xbmc . LOGERROR )
  xbmc . log ( str ( iI ) , level = xbmc . LOGERROR )
  return False
  if 33 - 33: O0OOo + ii11 * I11iIi1I - OOooOOo / Oo0o00o0Oo0 % IiiIIiiI11
def I1I1i1 ( src , dest , dp = None ) :
 if 21 - 21: I11iIi1I * iIii1I11I1II1 % Oo0o00o0Oo0 * i1IIi
 Ii11Ii1I = zipfile . ZipFile ( src , 'r' )
 O00oO = float ( len ( Ii11Ii1I . infolist ( ) ) )
 I11i1I1I = 0
 try :
  for oO0Oo in Ii11Ii1I . infolist ( ) :
   I11i1I1I += 1
   oOOoo0Oo = I11i1I1I / O00oO * 100
   if dp :
    dp . update ( int ( oOOoo0Oo ) )
   Ii11Ii1I . extract ( oO0Oo , dest )
   if dp . iscanceled ( ) :
    xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
    return False
 except Exception , iI :
  if 78 - 78: oo0O000OoO
  xbmc . log ( o0OoOoOO00 + ': Exception occurred' , level = xbmc . LOGERROR )
  xbmc . log ( str ( iI ) , level = xbmc . LOGERROR )
  xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
  return False
 return True
 if 71 - 71: ii11 + OooO0OO % i11iIiiIii + II1Iiii1111i - i1iiIII111ii
def IiI1i ( ) :
 if os . path . isfile ( '/etc/os-release' ) :
  oO0OOoO0 = open ( '/etc/os-release' )
  file = oO0OOoO0 . readlines ( )
  I111Ii111 = False
  for i111IiI1I in file :
   if 'ID=' in i111IiI1I and not '_ID' in i111IiI1I :
    I111Ii111 = i111IiI1I [ i111IiI1I . find ( '=' ) + 1 : i111IiI1I . find ( '\n' ) ] . rstrip ( '\n' ) . lower ( )
    if I111Ii111 in [ 'ember' ] :
     return True
   else :
    pass
  if I111Ii111 in [ 'ember' ] :
   return True
  else :
   return False
  oO0OOoO0 . close ( )
 else :
  return False
  if 70 - 70: IiiIIiiI11 . OOooOOo / O0OOo . IiiIIiiI11 - O0 / i1iiIII111ii
def o0oO0 ( ifname ) :
 ooOooo000oOO = socket . socket ( socket . AF_INET , socket . SOCK_DGRAM )
 try :
  Oo0oOOo = fcntl . ioctl ( ooOooo000oOO . fileno ( ) , 0x8927 , struct . pack ( '256s' , ifname [ : 15 ] ) )
  pass
 except IOError :
  if 58 - 58: II111iiii * ii11 * II1Iiii1111i / ii11
  return ''
  pass
 return '' . join ( [ '%02x:' % ord ( oO0o0OOOO ) for oO0o0OOOO in Oo0oOOo [ 18 : 24 ] ] ) [ : - 1 ]
 if 68 - 68: oooOOOOO - I1I11I1I1I - oO0o - II1Iiii1111i + oo0O000OoO
iiIIIII1i1iI = None
iiiI1I11i1 = None
IIi1i11111 = None
ooOO00O00oo = None
I1ii11iI = None
if 14 - 14: IiiIII111iI / i1iiIII111ii . IiiIII111iI . oo0O000OoO % I11iIi1I * oo0O000OoO
if 16 - 16: IiiIII111iI . OooO0OO + i11iIiiIii
try :
 iiIIIII1i1iI = urllib . unquote_plus ( params [ "url" ] )
except :
 pass
try :
 iiiI1I11i1 = urllib . unquote_plus ( params [ "name" ] )
except :
 pass
try :
 ooOO00O00oo = urllib . unquote_plus ( params [ "iconimage" ] )
except :
 pass
try :
 IIi1i11111 = int ( params [ "mode" ] )
except :
 pass
 if 38 - 38: i1iiIII111ii * ii11 . O0OOo
 if 98 - 98: OoooooooOO + oooOOOOO . IiiIII111iI
print "Mode: " + str ( IIi1i11111 )
print "URL: " + str ( iiIIIII1i1iI )
print "Name: " + str ( iiiI1I11i1 )
print "IconImage: " + str ( ooOO00O00oo )
if 67 - 67: i11iIiiIii - i1IIi % II1Iiii1111i . O0
if 77 - 77: i1iiIII111ii / oO0o
if 15 - 15: i1iiIII111ii . iIii1I11I1II1 . OoooooooOO / i11iIiiIii - IiiIIiiI11 . i1IIi
if IIi1i11111 == None or iiIIIII1i1iI == None or len ( iiIIIII1i1iI ) < 1 :
 IiII ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
